package com.example.voiceagent

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object Notes {
    private fun file(c: Context) = File(c.filesDir, "notes.json")
    private fun load(c: Context) = if (file(c).exists()) JSONArray(file(c).readText()) else JSONArray()

    fun add(c: Context, text: String) {
        val arr = load(c)
        val ts = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi")).format(Date())
        arr.put("$ts: $text")
        file(c).writeText(arr.toString())
    }

    fun list(c: Context): String {
        val arr = load(c)
        if (arr.length() == 0) return "Chưa có ghi chú nào."
        return (0 until arr.length()).joinToString("\n") { "${it + 1}. ${arr.getString(it)}" }
    }
}
