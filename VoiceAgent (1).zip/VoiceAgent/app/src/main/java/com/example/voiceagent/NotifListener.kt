package com.example.voiceagent

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    companion object { val recent = ArrayDeque<String>() }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val ex = sbn.notification.extras
        val title = ex.getCharSequence("android.title")?.toString() ?: ""
        val text = ex.getCharSequence("android.text")?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        synchronized(recent) {
            recent.addFirst("${sbn.packageName}: $title - $text")
            while (recent.size > 30) recent.removeLast()
        }
    }
}
