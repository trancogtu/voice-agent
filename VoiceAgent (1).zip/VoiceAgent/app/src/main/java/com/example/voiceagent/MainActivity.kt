package com.example.voiceagent

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var keyBox: EditText
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        keyBox = EditText(this).apply { hint = "Anthropic API key (sk-ant-...)"; setText(prefs.getString("key", "")) }
        val mic = Button(this).apply { text = "🎤 Nói với trợ lý" }
        val a11y = Button(this).apply { text = "1. Bật quyền Trợ năng (điều khiển máy)" }
        val notif = Button(this).apply { text = "2. Bật quyền đọc thông báo" }
        log = TextView(this).apply { textSize = 16f }
        val scroll = ScrollView(this).apply { addView(log) }
        listOf(keyBox, mic, a11y, notif).forEach { root.addView(it, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) }
        root.addView(scroll, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        tts = TextToSpeech(this) { tts.language = Locale("vi", "VN") }
        a11y.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        notif.setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        mic.setOnClickListener {
            prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) else listen()
        }
    }

    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) {
                    val said = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    handle(said)
                }
                override fun onError(e: Int) { append("⚠️ Không nghe rõ (mã $e)") }
                override fun onReadyForSpeech(p: Bundle?) { append("🎧 Đang nghe...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            })
        }
    }

    private fun handle(said: String) {
        append("🗣 Bạn: $said")
        val key = keyBox.text.toString().trim()
        Thread {
            val reply = try { Agent.run(applicationContext, key, said) } catch (e: Exception) { "Lỗi: ${e.message}" }
            runOnUiThread { append("🤖 $reply"); tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "r") }
        }.start()
    }

    private fun append(s: String) { log.append("$s\n\n") }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (g.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
    }
}
