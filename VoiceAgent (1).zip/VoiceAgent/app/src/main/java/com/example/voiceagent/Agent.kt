package com.example.voiceagent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Agent {
    private const val MODEL = "claude-sonnet-5-5"
    private const val SYSTEM = """Bạn là trợ lý giọng nói điều khiển điện thoại Android của người dùng.
- Trả lời bằng tiếng Việt, NGẮN GỌN (1-3 câu) vì câu trả lời sẽ được đọc thành tiếng.
- Khi cần thao tác điện thoại: dùng open_app, read_screen, tap, type_text, scroll, press. Sau mỗi thao tác hãy read_screen để kiểm tra kết quả trước khi làm bước tiếp theo.
- Khi cần thông tin mới/tin tức/mạng xã hội/bài báo: dùng web_search rồi fetch_url nếu cần đọc chi tiết.
- Khi người dùng muốn ghi nhớ: dùng save_note. Muốn nghe thông báo: dùng read_notifications rồi tóm tắt.
- Với hành động không thể hoàn tác (gửi tin nhắn, chuyển tiền, xóa, mua hàng): PHẢI hỏi xác nhận bằng lời trước khi thực hiện."""

    private val history = JSONArray()

    fun run(ctx: Context, apiKey: String, userText: String): String {
        if (history.length() > 30) history.let { while (it.length() > 0) it.remove(0) }
        history.put(JSONObject().put("role", "user").put("content", userText))
        for (step in 0 until 12) {
            val resp = call(apiKey)
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            when (resp.optString("stop_reason")) {
                "tool_use" -> {
                    val results = JSONArray()
                    for (i in 0 until content.length()) {
                        val b = content.getJSONObject(i)
                        if (b.getString("type") == "tool_use") {
                            val out = Tools.execute(ctx, b.getString("name"), b.getJSONObject("input"))
                            results.put(JSONObject().put("type", "tool_result")
                                .put("tool_use_id", b.getString("id")).put("content", out))
                        }
                    }
                    history.put(JSONObject().put("role", "user").put("content", results))
                }
                "pause_turn" -> {} // web_search chạy dài: gửi lại để tiếp tục
                else -> return (0 until content.length()).map { content.getJSONObject(it) }
                    .filter { it.getString("type") == "text" }.joinToString(" ") { it.getString("text") }
            }
        }
        return "Tôi làm chưa xong, bạn thử nói lại cụ thể hơn nhé."
    }

    private fun call(apiKey: String): JSONObject {
        val body = JSONObject().put("model", MODEL).put("max_tokens", 1024).put("system", SYSTEM)
            .put("tools", Tools.definitions()).put("messages", history)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 30000; c.readTimeout = 120000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", apiKey)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream.bufferedReader().readText()
        if (c.responseCode !in 200..299) throw RuntimeException("API ${c.responseCode}: $text")
        return JSONObject(text)
    }
}
