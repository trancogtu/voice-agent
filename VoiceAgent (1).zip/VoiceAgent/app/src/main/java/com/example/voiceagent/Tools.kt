package com.example.voiceagent

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Tools {
    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
        )

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)

    fun definitions(): JSONArray = JSONArray().apply {
        put(tool("open_app", "Mở một ứng dụng trên điện thoại theo tên (vd: Zalo, YouTube, Facebook, Chrome).",
            JSONObject().put("name", str("Tên ứng dụng")), listOf("name")))
        put(tool("read_screen", "Đọc toàn bộ chữ đang hiển thị trên màn hình hiện tại."))
        put(tool("tap", "Bấm vào nút/mục có chữ này trên màn hình.",
            JSONObject().put("text", str("Chữ của nút/mục")), listOf("text")))
        put(tool("type_text", "Gõ chữ vào ô nhập đang được chọn.",
            JSONObject().put("text", str("Nội dung")), listOf("text")))
        put(tool("scroll", "Cuộn màn hình.",
            JSONObject().put("direction", JSONObject().put("type", "string").put("enum", JSONArray(listOf("down", "up")))), listOf("direction")))
        put(tool("press", "Nhấn phím hệ thống: back, home, recents, notifications.",
            JSONObject().put("key", str("back|home|recents|notifications")), listOf("key")))
        put(tool("read_notifications", "Lấy các thông báo gần đây của điện thoại."))
        put(tool("save_note", "Lưu một ghi chú cho người dùng.",
            JSONObject().put("text", str("Nội dung ghi chú")), listOf("text")))
        put(tool("list_notes", "Đọc lại các ghi chú đã lưu."))
        put(tool("fetch_url", "Tải và đọc nội dung chữ của một trang web / bài báo / bài đăng công khai.",
            JSONObject().put("url", str("Địa chỉ https://...")), listOf("url")))
        // Công cụ tìm kiếm web do Anthropic chạy phía server
        put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5))
    }

    fun execute(ctx: Context, name: String, input: JSONObject): String = try {
        val a11y = PhoneAccessibilityService.instance
        fun needA11y(block: (PhoneAccessibilityService) -> String) =
            if (a11y == null) "Chưa bật quyền Trợ năng cho Voice Agent." else block(a11y)
        when (name) {
            "open_app" -> openApp(ctx, input.getString("name"))
            "read_screen" -> needA11y { it.readScreen() }
            "tap" -> needA11y { if (it.tapText(input.getString("text"))) "Đã bấm." else "Không tìm thấy mục đó." }
            "type_text" -> needA11y { if (it.typeText(input.getString("text"))) "Đã gõ." else "Không có ô nhập nào được chọn." }
            "scroll" -> needA11y { if (it.scroll(input.getString("direction") == "down")) "Đã cuộn." else "Không cuộn được." }
            "press" -> needA11y { if (it.press(input.getString("key"))) "Xong." else "Phím không hợp lệ." }
            "read_notifications" -> synchronized(NotifListener.recent) {
                if (NotifListener.recent.isEmpty()) "Không có thông báo nào (hoặc chưa cấp quyền đọc thông báo)."
                else NotifListener.recent.take(15).joinToString("\n")
            }
            "save_note" -> { Notes.add(ctx, input.getString("text")); "Đã lưu ghi chú." }
            "list_notes" -> Notes.list(ctx)
            "fetch_url" -> fetchUrl(input.getString("url"))
            else -> "Công cụ không tồn tại."
        }
    } catch (e: Exception) { "Lỗi: ${e.message}" }

    private fun openApp(ctx: Context, appName: String): String {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(intent, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(appName, ignoreCase = true)
        } ?: return "Không tìm thấy ứng dụng \"$appName\"."
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "Không mở được."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return "Đã mở ${match.loadLabel(pm)}."
    }

    private fun fetchUrl(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) VoiceAgent")
        c.connectTimeout = 15000; c.readTimeout = 15000
        val html = c.inputStream.bufferedReader().readText()
        return html.replace(Regex("(?s)<(script|style)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim().take(8000)
    }
}
