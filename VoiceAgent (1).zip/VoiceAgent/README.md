# Voice Agent – trợ lý giọng nói điều khiển Android

## Cách chạy
1. Cài Android Studio, chọn File > Open > thư mục VoiceAgent, đợi Gradle sync.
2. Cắm điện thoại (bật Gỡ lỗi USB) hoặc dùng máy ảo, bấm Run.
3. Mở app, dán Anthropic API key (lấy tại console.anthropic.com).
4. Bấm "1. Bật quyền Trợ năng" -> tìm "Voice Agent" -> bật.
5. Bấm "2. Bật quyền đọc thông báo" -> bật cho Voice Agent.
6. Bấm "🎤 Nói với trợ lý" rồi ra lệnh.

## Ví dụ lệnh
- "Mở YouTube và tìm nhạc Sơn Tùng"
- "Đọc thông báo của tôi"
- "Ghi chú: mai 9 giờ họp với khách"
- "Đọc lại các ghi chú"
- "Tìm tin mới nhất về giá vàng hôm nay"
- "Đọc bài báo này: https://..."

## Cấu trúc
- Agent.kt: vòng lặp agent (Claude + công cụ)
- Tools.kt: các công cụ (mở app, bấm, gõ, cuộn, thông báo, ghi chú, tìm web)
- PhoneAccessibilityService.kt: điều khiển màn hình
- NotifListener.kt: đọc thông báo
- Notes.kt: lưu ghi chú
- MainActivity.kt: giọng nói vào/ra

## Lưu ý
- API key lưu trong máy để thử nghiệm; bản chính thức nên dùng server trung gian.
- Facebook/TikTok/Instagram không có API mở: agent lấy dữ liệu bằng cách mở app và đọc màn hình, hoặc đọc trang công khai qua web.
- Các app ngân hàng/thanh toán thường chặn Trợ năng.
